# Icon sources

Five 1024 × 1024 PNG canvases. Transparent backgrounds. Integration shapes preserved rather than redrawn to force uniform strokes. OBS source is a small official raster, so enlarged edges may be softer. Original integration colors are retained, including Open Design #202020 outside the Stream Machine palette.

- Stream Machine: original artwork generated using built-in imagegen. Prompt: centered bold geometric broadcast/play mechanism, black #111111, small blue #1677ff signal accent, transparent square, no text, gradients or shadows. Generated raster may contain tonal variation rather than exact flat color tokens.
- Twitch: first brand SVG embedded in https://www.twitch.tv/ . Retrieved 2026-11-02. Owner: Twitch. Trademark asset; no separate reuse license asserted. Brand guidance: https://brand.twitch.com/ .
- OBS: https://obsproject.com/assets/images/new_icon_small-r.png . Retrieved 2026-11-02. Owner: OBS Project. No separate logo reuse license asserted.
- Stream Deck: official monochrome logo-stream-deck SVG from https://docs.elgato.com/resources/icons/ . Retrieved 2026-11-02. Owner: Elgato/Corsair. Branding guidance: https://docs.elgato.com/guidelines/branding/ . No separate logo reuse license asserted.
- Open Design: https://open-design.ai/images/brand-symbol.svg . Retrieved 2026-11-02. Owner: Open Design. No separate logo reuse license asserted.

Original integration files retained in sources/. Icons exported with proportional scaling and centered padding. No directory upload or brand.html change performed.
