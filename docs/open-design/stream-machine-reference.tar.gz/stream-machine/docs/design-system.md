---
name: "Stream Machine"
category: Brands
surface: web
colors:
  background: "#080c0d"
  foreground: "#edf2f7"
  accent: "#9aff57"
  surface: "#11191b"
  muted: "#aab8c6"
  border: "#617477"
  info: "#65e3ef"
  error: "#ff767d"
  warning: "#ffcf70"
  elevated: "#1b272a"
---

# Stream Machine

Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play.

## Direction

Dystopian machine console; charcoal metal, phosphor green, cold cyan, restrained warning red. User-approved replacement for earlier white/blue default.

## Color Palette

| Role | Hex | Usage |
| --- | --- | --- |
| background | #080c0d | page canvas |
| foreground | #edf2f7 | headings and body |
| accent | #9aff57 | primary actions with dark text |
| surface | #11191b | quiet reading panels |
| muted | #aab8c6 | supporting text |
| border | #617477 | control outlines |
| info | #65e3ef | links and information |
| error | #ff767d | errors paired with text |
| warning | #ffcf70 | caution paired with text |
| elevated | #1b272a | raised surfaces |

## Typography and layout

- 20px body, 18px labels, 1.7 body line height.
- Geist Serif headlines; Geist Mono body and controls; Geist Pixel Square only for short machine labels.
- 48px controls; minimum 44px targets; visible focus outlines.
- Quiet opaque reading panels over faint static scanlines and 48px etched grids.
- Phosphor actions use dark text; cyan information; red errors always paired with labels.
- No flashing, constant animation, or texture over text.
- Approved editable reference: docs/kit.dark.html; styles: docs/readable-dark.css and docs/machine-console.css.
- Display weight: 400. Serif fallback: Georgia, serif. Mono fallback: ui-monospace, monospace.
- Corners: 4px; borders: 1px; spacing: 8px grid.
- Headline size: responsive 40–72px.
- Local WOFF2 fonts: docs/fonts/. Load fonts explicitly; family names alone do not load files.

## Texture and motion

Procedural CSS texture; static scanlines and etched grid behind opaque content panels. No flashing or continuous animation. Honor reduced motion.

## Accessibility

Body contrast at least 4.5:1; essential graphics at least 3:1. Preserve zoom, keyboard focus, readable line lengths, and reflow. Never use color alone for status.

## Voice

Spend more time streaming and less time doing manual labor with Stream Machine. Direct, practical copy. No invented performance claims.

## Source ownership

Use docs/kit.dark.html as approved visual reference. Generated system/ previews may be rebuilt by host; preserve custom styles in docs/.

## Ligatures

Enable common and contextual ligatures: font-variant-ligatures: common-ligatures contextual; font-feature-settings: "liga" 1, "clig" 1, "calt" 1. Use font-provided glyphs; CSS cannot add missing programming ligatures. Preserve literal source text for copy and accessibility.

## Brand identity

- Brand name: Stream Machine
- Tagline: Spend more time streaming
- Supporting campaign copy: The machine works. You play.
