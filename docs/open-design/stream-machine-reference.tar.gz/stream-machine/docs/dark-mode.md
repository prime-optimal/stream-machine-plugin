# Night shift dark mode
Open ../system/kit.dark.html for component showcase.
Tokens: ../system/tokens.dark.json and ../system/variables.dark.css.

Near-black #080c10 canvas; #10161d panels; #18212b raised surfaces.
Text #edf2f7; secondary #b4c0cc; supporting #94a3b3.
Blue #398bff actions use dark labels. Links #70aaff.
Green #7ee787 reserved for successful operations and automation status, paired with text.
Borders #526477 for controls; #2b3947 for decorative dividers.

Geist Serif leads. Geist Mono labels controls and technical details. Geist Pixel marks the small header label.
Local fonts extracted from supplied geist-font-v1.9.0.zip into docs/fonts/.
Light mode unchanged. Dark colors intentionally extend registered light palette following requested hacker direction.
No glow, glitch, or continuous blinking. Existing showcase interactions remain unchanged.
Dark tokens are explicit overrides; regeneration from original light seed can overwrite them.
