---
name: "Stream Machine"
category: Brands
surface: web
colors:
  midnight: "#080c0d"
  text: "#edf2f7"
  phosphor: "#9aff57"
  metal: "#11191b"
  secondary: "#aab8c6"
  steel: "#617477"
---

# Stream Machine

> Category: Brands

> Surface: web

*Spend more time streaming*

Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play.

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Midnight | `#080c0d` | page canvas |
| foreground | Text | `#edf2f7` | headings and body |
| accent | Phosphor | `#9aff57` | primary actions with dark text |
| surface | Metal | `#11191b` | quiet reading panels |
| muted | Secondary | `#aab8c6` | supporting text |
| border | Steel | `#617477` | control outlines |

## Typography
- **Display:** Geist Serif — weights 400 — fallbacks: Georgia, serif
- **Body:** Geist Mono — weights 400 — fallbacks: ui-monospace, monospace
- **Mono:** Geist Mono — weights 400 — fallbacks: ui-monospace, monospace

## Voice & Tone

- **Adjectives:** (none yet)
- **Tone:** Spend more time streaming and less time doing manual labor with Stream Machine.

### Messaging pillars
- Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play.
- Spend more time streaming and less time doing manual labor with Stream Machine.  Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics.  Download all your clips at once or generate subtitles automatically whenever you get clipped.  Stream Machine works so you can play.

### Vocabulary
- **Use:** (none yet)
- **Avoid:** (none yet)

## Imagery

- **Style:** Dystopian machine console; charcoal metal, phosphor green, cold cyan, restrained warning red.
- **Subjects:** robotic hardware, industrial panel details
- **Treatment:** Procedural CSS texture; static scanlines and etched grid behind opaque content panels.
- **Avoid:** decorative glitching, flashing, illegible microtype, film logos or copied franchise artwork

## Layout

- **Radius:** 4px
- **Border weight:** 1px
- **Spacing:** 8px baseline grid

### Posture rules
- 20px body, 18px labels, 1.7 body line height.
- Geist Serif headlines; Geist Mono body and controls; Geist Pixel Square only for short machine labels.
- 48px controls; minimum 44px targets; visible focus outlines.
- Quiet opaque reading panels over faint static scanlines and 48px etched grids.
- Phosphor actions use dark text; cyan information; red errors always paired with labels.
- No flashing, constant animation, or texture over text.
- Approved editable reference: docs/kit.dark.html; styles: docs/readable-dark.css and docs/machine-console.css.
- Enable common and contextual ligatures: font-variant-ligatures: common-ligatures contextual; font-feature-settings: "liga" 1, "clig" 1, "calt" 1. Use font-provided glyphs; CSS cannot add missing programming ligatures. Preserve literal source text for copy and accessibility.
