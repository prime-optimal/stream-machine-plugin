# Stream Machine — Brand Guide

*Spend more time streaming*

Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play.

Extracted from designmd://spend-more-time-streaming.

## Color roles

- **Midnight** (`#080c0d`) — background: page canvas
- **Text** (`#edf2f7`) — foreground: headings and body
- **Phosphor** (`#9aff57`) — accent: primary actions with dark text
- **Metal** (`#11191b`) — surface: quiet reading panels
- **Secondary** (`#aab8c6`) — muted: supporting text
- **Steel** (`#617477`) — border: control outlines

## Typography

- Display: Geist Serif
- Body: Geist Mono
- Mono: Geist Mono

## Messaging pillars

- Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play.
- Spend more time streaming and less time doing manual labor with Stream Machine.  Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics.  Download all your clips at once or generate subtitles automatically whenever you get clipped.  Stream Machine works so you can play.
