---
name: "Spend more time streaming"
description: "Spend more time streaming and less time doing manual labor with Stream Machine. Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics. Download all your clips at once or generate subtitles automatically whenever you get clipped. Stream Machine works so you can play."
colors:
  background: "#ffffff"
  foreground: "#111111"
  accent: "#1677ff"
  surface: "#f7f8fa"
  muted: "#6b7280"
  border: "#d9dee7"
typography:
  display: "Inter"
  body: "Inter"
radius: "8px"
spacing: "8px baseline grid"
---

# Spend more time streaming Design System

## Overview

Spend more time streaming and less time doing manual labor with Stream Machine.  Connect your Twitch account and instantly make new stream overlays, alerts, and other graphics.  Download all your clips at once or generate subtitles automatically whenever you get clipped.  Stream Machine works so you can play.

## Source Material

Source links: https://github.com/prime-optimal/stream-machine-plugin
GitHub repositories: https://github.com/prime-optimal/stream-machine-plugin

## Components

- Button
- Card
- Form field
- Navigation