<!-- stream-machine-roadmap:epic-deck -->
Add and press one button in a dedicated test profile.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [x] #31: Read my Stream Deck profiles and actions
- [x] #32: Preview one Stream Deck test button
- [x] #33: Add one working Stream Deck button

## Files

Proposed ownership: `src/adapters/streamdeck/`, `recipes/streamdeck/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.

## Completion evidence

Completed in [PR #56](https://github.com/prime-optimal/stream-machine-plugin/pull/56) and [integration evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md).