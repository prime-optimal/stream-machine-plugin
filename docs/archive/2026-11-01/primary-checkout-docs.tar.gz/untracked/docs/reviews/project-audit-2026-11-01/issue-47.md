<!-- stream-machine-roadmap:onboarding -->
Onboarding points to the working Twitch, OBS, Stream Deck, or creative path with the fewest setup steps.

## Reuse

Discover existing accounts, services, and plugins first.

## Done when

- [x] Show what is already available and what the selected demo still needs.
- [x] Allow unrelated setup to be skipped, so OBS or Stream Deck does not wait for Twitch.
- [x] Get the user to one harmless working check and keep unattended activation separate.

## Needs

Nothing else needs to finish first.

## Keep it small

No mandatory installation of every provider or full cross-device onboarding system.

## Files

Use a separate worktree. Start in `src/ui/`, `skills/` and the existing code named above. Agree before editing another task's files.


Part of #20.

## Completion evidence

Completed in [PR #56](https://github.com/prime-optimal/stream-machine-plugin/pull/56) and [integration evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md). [Onboarding skill](https://github.com/prime-optimal/stream-machine-plugin/blob/main/skills/onboarding/SKILL.md) selects a demo, checks its provider, skips unrelated setup, and keeps unattended activation separate. Native-host acceptance remains #46.