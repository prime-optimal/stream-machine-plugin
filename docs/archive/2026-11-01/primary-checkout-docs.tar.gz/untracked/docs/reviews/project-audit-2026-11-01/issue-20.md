<!-- stream-machine-roadmap:epic-experience -->
Open the plugin and reach a working demo without unnecessary setup.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [ ] #46: Open and use Stream Machine in the native app
- [x] #47: Help me choose and start a working demo
- [ ] #48: Add one native shortcut that improves a demo

## Files

Proposed ownership: `src/ui/`, `skills/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.