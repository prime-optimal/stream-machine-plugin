<!-- stream-machine-roadmap:epic-creative -->
Reuse the existing Sealos OpenDesign service and its HyperFrames workflow.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [x] #43: Make an asset with the existing OpenDesign service
- [x] #44: Generate an HTML overlay with the existing HyperFrames workflow
- [ ] #45: Make one artwork draft with the Canva plugin

## Files

Proposed ownership: `src/adapters/design/`, `src/adapters/hyperframes/`, `recipes/creative/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.