<!-- stream-machine-roadmap:epic-automation -->
Show an OBS alert from one Twitch event while chat is closed.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [x] #34: Subscribe to one Twitch event
- [x] #35: Log Twitch events and ignore duplicate messages
- [x] #36: Keep the alert worker running after chat closes
- [x] #37: Arm and pause the one event-to-alert rule
- [x] #38: Show an OBS alert from Twitch while chat is closed

## Files

Proposed ownership: `src/events/`, `src/worker/`, `recipes/alerts/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.

## Completion evidence

Completed in [PR #56](https://github.com/prime-optimal/stream-machine-plugin/pull/56) and [integration evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md).