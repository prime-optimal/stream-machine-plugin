The board now starts with six visible demos in the [Demo roadmap view](https://github.com/users/prime-optimal/projects/18/views/1). The [roadmap source](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/roadmap.md) and [reuse evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/reuse-evidence.md) are in PR #55.

## Current plan

- Four core demonstrations: Twitch title update #27, OBS alert #30, Stream Deck button #33, and a real Twitch event that triggers an OBS alert while chat is closed #38.
- Reuse now: existing Twitch OAuth #25, Sealos OpenDesign and installed scenarios #43, and OpenDesign HyperFrames #44.
- V2 covers clips, game information, and artwork. V3 covers useful metrics and native shortcuts.
- Generic frameworks, broad hardening, hosted multi-user work, and public distribution stay later.

## Completed board changes

- [x] Rewrote tasks with a visible outcome, existing work, and a short Done when checklist.
- [x] Added Reuse notes to the six default demo cards.
- [x] Moved OpenDesign and HyperFrames to V1 at priority P0.
- [x] Removed all blockers on #13 and reduced native prerequisite links from 56 to 25.
- [x] Reset unfinished work to open/Todo as requested. Kept #22, #23, #24, and #29 closed as Not planned, not completed.
- [x] Verified issue states, board fields, native relationships, milestone placement, and saved views.
- [x] Merge the updated roadmap documentation in PR #55.

Existing OAuth and deployment acceptance are recorded evidence. The remaining issues prove the Stream Machine hookup. The current OpenDesign tool connection returned Transport closed and needs verification; that is not a reason to redeploy the existing service.