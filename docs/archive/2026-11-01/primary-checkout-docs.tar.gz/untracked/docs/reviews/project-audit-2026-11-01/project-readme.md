# Stream Machine

## Current work

PR #56 merged the live demos and private plugin v0.2.0. Twitch title update/read-back/restoration, OBS alert play/replay, a physical Stream Deck press, and an independent event worker have recorded evidence. The worker remains paused.

- #46 verifies installed v0.2.0 tools and native app view after reload. Browser preview is not native-host proof.
- #49 completes the four-demo acceptance, including #46 and a full chat-close demonstration. Existing worker proof disconnected the MCP client/server.

## Board views

- Current work: unfinished V1 tasks.
- Next demos: clips, games, Canva artwork, additional Twitch reads, metrics, and native shortcuts.
- Later: optional sharing and shared-code cleanup.
- All open work: unfinished tasks and parent groups. Closed work remains in project history and repository issues.

OBS #15, Stream Deck #16, Event-to-OBS #17, and onboarding #47 are complete. Twitch #14 and creative #19 remain open for expansion tasks #53 and #45. No dates promised.

## Output and safety boundaries

HyperFrames produces editable, playable HTML. The MP4 experiment was reverted; the original Sealos deployment was restored. The original mock core remains mock-only. Real provider actions use the separate local demo tools and explicit authorization. Never start broadcasts, alter active Deck profiles, or arm unattended rules during board maintenance.

## Evidence

- [Merged implementation](https://github.com/prime-optimal/stream-machine-plugin/pull/56)
- [Integration verification](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md)
- [Release verification and remaining native checks](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/release-0.2.0.md)
- [Roadmap](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/roadmap.md)
- [Reuse evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/reuse-evidence.md)
