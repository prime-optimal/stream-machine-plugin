<!-- stream-machine-roadmap:epic-obs -->
Connect to the running OBS instance and show one test alert.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [x] #28: Connect Stream Machine to the running OBS instance
- [x] #30: Show one alert in OBS

## Shelved, not completed

- #29: Shelved: add another OBS server only for a missing feature

## Files

Proposed ownership: `src/adapters/obs/`, `recipes/obs/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.

## Completion evidence

Merged PR #56 verifies OBS connection, alert play/replay, and unchanged broadcast state. See [integration evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md). #29 remains shelved as Not planned.
