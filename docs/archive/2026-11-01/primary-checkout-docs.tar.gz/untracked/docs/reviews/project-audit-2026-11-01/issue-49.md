<!-- stream-machine-roadmap:personal-release -->
Run a short demonstration of Twitch title update, OBS alert, Stream Deck button, and chat-closed automation.

## Reuse

Use the existing services and the small implementations completed by those demo issues.

## Done when

- [x] Show the real title update and its read-back.
- [x] Show the OBS alert and press the working Stream Deck test button.
- [ ] Close chat and show a real Twitch event trigger the OBS alert. Record the known limits and cleanup.

## Needs

- #27: Change my Twitch title after preview
- #33: Add one working Stream Deck button
- #38: Show an OBS alert from Twitch while chat is closed
- #46: Open and use Stream Machine in the native app

## Keep it small

OpenDesign and HyperFrames are parallel V1 reuse wins. They can finish independently of the four core demonstrations. Broad production hardening is not a release requirement.

## Files

Use a separate worktree. Start in `docs/releases/`, `packaging/`, `tests/integration/` and the existing code named above. Agree before editing another task's files.


Part of #21.

## Remaining acceptance

[PR #56](https://github.com/prime-optimal/stream-machine-plugin/pull/56) and [integration evidence](https://github.com/prime-optimal/stream-machine-plugin/blob/main/docs/demos/integration.md) records title update/read-back/restoration, OBS play/replay, and the physical Stream Deck press. Worker evidence disconnected the MCP client/server and received a real event. Native v0.2.0 view verification in #46 and a complete chat-close demonstration remain. Do not treat browser preview as native-host proof. Worker remains paused.
