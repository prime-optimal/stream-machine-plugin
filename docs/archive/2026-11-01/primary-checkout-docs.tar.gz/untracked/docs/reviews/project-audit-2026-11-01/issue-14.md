<!-- stream-machine-roadmap:epic-twitch -->
Reuse Twitch OAuth and change one channel title after preview.

This is a group of tasks, not a framework to build first. Open a child issue for its short Done when checklist.

## Tasks

- [x] #25: Use the existing Twitch login in Stream Machine
- [x] #26: Read my current Twitch title and category
- [x] #27: Change my Twitch title after preview
- [ ] #53: Add the next Twitch read needed by a demo

## Files

Proposed ownership: `src/auth/`, `src/adapters/twitch/`. Reuse working code before creating new modules. Coordinate shared-file edits with the other demo owners.